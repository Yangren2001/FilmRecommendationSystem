# encoding = utf-8

class Model:

    def __init__(self):
        pass

    def buildModel(self, **kwargs):
        pass

    def train(self, **kwargs):
        pass

    def predict(self, **kwargs):
        pass

    def get_model(self, **kwargs):
        pass

    def adjustModel(self, **kwargs):
        pass

    def test(self, **kwargs):
        pass